﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace frmFirstPage
{
    public partial class Form1 : Form
    {
        public String foodListItem { get; set; }
        public DateTime expListDate { get; set; }
        public Form1()
        {
            InitializeComponent();
            selectionPanel.Location = btnHome.Location;
            uctrlHome1.BringToFront();
            btnStart.BringToFront();
            btnQuit.BringToFront();
        }

        private void btnFoodList_Click(object sender, EventArgs e)
        {
            selectionPanel.Location = btnFoodList.Location;
            uctrlInventory1.BringToFront();
            chkFoods.BringToFront();
            stExpirationDate.BringToFront();
            btnAddFood.BringToFront();
            txtFoodItem.BringToFront();
            lblExpirationDate.BringToFront();
            lblFoodItem.BringToFront();
            dtExpiration.BringToFront();
            btnRemove.BringToFront();
            btnAddFood.BringToFront();
            btnGoogle.BringToFront();
            picError.BringToFront();
            picError.Hide();

        }

        private void btnHome_Click(object sender, EventArgs e)
        {
            selectionPanel.Location = btnHome.Location;
            uctrlHome1.BringToFront();
            btnStart.BringToFront();
            btnQuit.BringToFront();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            selectionPanel.Location = btnFoodList.Location;
            uctrlInventory1.BringToFront();
            chkFoods.BringToFront();
            stExpirationDate.BringToFront();
            btnAddFood.BringToFront();
            txtFoodItem.BringToFront();
            lblExpirationDate.BringToFront();
            lblFoodItem.BringToFront();
            dtExpiration.BringToFront();
            btnRemove.BringToFront();
            btnAddFood.BringToFront();
            btnGoogle.BringToFront();
            picError.BringToFront();
            picError.Hide();
        }

        private void btnAddFood_Click(object sender, EventArgs e)
        {
            bool badFood = false;
            DateTime expDay;
            if(!txtFoodItem.Text.Equals(""))
            {
                    chkFoods.Items.Add(txtFoodItem.Text);
                    stExpirationDate.Items.Add(dtExpiration.Value);
            }

            for(int i = 0; i < stExpirationDate.Items.Count; i++)
            {
                expDay = Convert.ToDateTime(stExpirationDate.Items[i]);
                if ((expDay - DateTime.Today).TotalDays <= 15)
                {
                    badFood = true;
                }
                
            }

            if(badFood)
            {
                picError.Show();
            }
            else
            {
                picError.Hide();
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            bool badFood = false;
            DateTime expDay;
            for (int i = 0; i < chkFoods.Items.Count; i++)
            {
                if (chkFoods.GetItemCheckState(i) == CheckState.Checked)
                {
                    stExpirationDate.Items.RemoveAt(i);
                    chkFoods.Items.RemoveAt(i);
                    i = -1;
                }
            }

            for (int i = 0; i < stExpirationDate.Items.Count; i++)
            {
                expDay = Convert.ToDateTime(stExpirationDate.Items[i]);
                if ((expDay - DateTime.Today).TotalDays <= 15)
                {
                    badFood = true;
                }

            }

            if (badFood)
            {
                picError.Show();
            }
            else
            {
                picError.Hide();
            }

        }

        private void btnGoogle_Click(object sender, EventArgs e)
        {
            string searchString = "Recipe for ";
            for (int i = 0; i < chkFoods.Items.Count; i++)
            {
                if (chkFoods.GetItemCheckState(i) == CheckState.Checked)
                {
                    searchString += chkFoods.Items[i].ToString() + " ";
                }
            }

            System.Diagnostics.Process.Start("https://www.google.com/search?newwindow=1&source=hp&ei=p3h2WqqlAqKG5wKTx7LgAg&q=" + searchString);
        }

        private void hover_over(object sender, EventArgs e)
        {
            string errorMsg = "";
            DateTime expDay;

            for (int i = 0; i < stExpirationDate.Items.Count; i++)
            {
                expDay = Convert.ToDateTime(stExpirationDate.Items[i]);

                if ((expDay - DateTime.Today).TotalDays <= 15)
                {
                    errorMsg += chkFoods.Items[i].ToString() + " is about to go bad! Add it to a recipe!\n";
                }

            }

            ttErrorMsg.SetToolTip(picError, errorMsg);
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void uctrlInventory1_Load(object sender, EventArgs e)
        {

        }
    }
}
