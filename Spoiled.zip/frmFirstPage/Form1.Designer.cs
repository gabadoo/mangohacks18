﻿namespace frmFirstPage
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.selectionPanel = new System.Windows.Forms.Panel();
            this.btnFoodList = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnStart = new System.Windows.Forms.Button();
            this.chkFoods = new System.Windows.Forms.CheckedListBox();
            this.stExpirationDate = new System.Windows.Forms.ListBox();
            this.btnAddFood = new System.Windows.Forms.Button();
            this.txtFoodItem = new System.Windows.Forms.TextBox();
            this.lblFoodItem = new System.Windows.Forms.Label();
            this.dtExpiration = new System.Windows.Forms.DateTimePicker();
            this.lblExpirationDate = new System.Windows.Forms.Label();
            this.btnGoogle = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.picError = new System.Windows.Forms.PictureBox();
            this.ttErrorMsg = new System.Windows.Forms.ToolTip(this.components);
            this.btnQuit = new System.Windows.Forms.Button();
            this.uctrlInventory1 = new frmFirstPage.uctrlInventory();
            this.uctrlHome1 = new frmFirstPage.uctrlHome();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picError)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.selectionPanel);
            this.panel1.Controls.Add(this.btnFoodList);
            this.panel1.Controls.Add(this.btnHome);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 599);
            this.panel1.TabIndex = 0;
            // 
            // selectionPanel
            // 
            this.selectionPanel.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.selectionPanel.Location = new System.Drawing.Point(-8, 80);
            this.selectionPanel.Name = "selectionPanel";
            this.selectionPanel.Size = new System.Drawing.Size(21, 59);
            this.selectionPanel.TabIndex = 2;
            // 
            // btnFoodList
            // 
            this.btnFoodList.BackColor = System.Drawing.Color.DimGray;
            this.btnFoodList.FlatAppearance.BorderSize = 0;
            this.btnFoodList.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFoodList.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFoodList.ForeColor = System.Drawing.Color.White;
            this.btnFoodList.Image = global::frmFirstPage.Properties.Resources.plateIcon_1_1;
            this.btnFoodList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnFoodList.Location = new System.Drawing.Point(0, 145);
            this.btnFoodList.Name = "btnFoodList";
            this.btnFoodList.Size = new System.Drawing.Size(200, 59);
            this.btnFoodList.TabIndex = 3;
            this.btnFoodList.Text = "Inventory";
            this.btnFoodList.UseVisualStyleBackColor = false;
            this.btnFoodList.Click += new System.EventHandler(this.btnFoodList_Click);
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.DimGray;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.Image = global::frmFirstPage.Properties.Resources.homeLogo;
            this.btnHome.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHome.Location = new System.Drawing.Point(0, 80);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(200, 59);
            this.btnHome.TabIndex = 2;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = false;
            this.btnHome.Click += new System.EventHandler(this.btnHome_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(200, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(708, 84);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnStart.Font = new System.Drawing.Font("Open Sans", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStart.Location = new System.Drawing.Point(325, 474);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(171, 41);
            this.btnStart.TabIndex = 3;
            this.btnStart.Text = "Get Started";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // chkFoods
            // 
            this.chkFoods.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.chkFoods.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.chkFoods.FormattingEnabled = true;
            this.chkFoods.Location = new System.Drawing.Point(287, 256);
            this.chkFoods.Name = "chkFoods";
            this.chkFoods.Size = new System.Drawing.Size(192, 212);
            this.chkFoods.TabIndex = 5;
            // 
            // stExpirationDate
            // 
            this.stExpirationDate.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.stExpirationDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.stExpirationDate.FormattingEnabled = true;
            this.stExpirationDate.Location = new System.Drawing.Point(614, 256);
            this.stExpirationDate.Name = "stExpirationDate";
            this.stExpirationDate.Size = new System.Drawing.Size(192, 210);
            this.stExpirationDate.TabIndex = 6;
            // 
            // btnAddFood
            // 
            this.btnAddFood.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnAddFood.Font = new System.Drawing.Font("Linux Biolinum G", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddFood.Location = new System.Drawing.Point(485, 521);
            this.btnAddFood.Name = "btnAddFood";
            this.btnAddFood.Size = new System.Drawing.Size(97, 54);
            this.btnAddFood.TabIndex = 8;
            this.btnAddFood.Text = "Add Food Item";
            this.btnAddFood.UseVisualStyleBackColor = false;
            this.btnAddFood.Click += new System.EventHandler(this.btnAddFood_Click);
            // 
            // txtFoodItem
            // 
            this.txtFoodItem.Location = new System.Drawing.Point(325, 521);
            this.txtFoodItem.Name = "txtFoodItem";
            this.txtFoodItem.Size = new System.Drawing.Size(154, 20);
            this.txtFoodItem.TabIndex = 10;
            // 
            // lblFoodItem
            // 
            this.lblFoodItem.AutoSize = true;
            this.lblFoodItem.BackColor = System.Drawing.Color.Beige;
            this.lblFoodItem.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblFoodItem.Font = new System.Drawing.Font("Linux Biolinum G", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFoodItem.Location = new System.Drawing.Point(255, 521);
            this.lblFoodItem.Name = "lblFoodItem";
            this.lblFoodItem.Size = new System.Drawing.Size(64, 17);
            this.lblFoodItem.TabIndex = 11;
            this.lblFoodItem.Text = "Food Item";
            // 
            // dtExpiration
            // 
            this.dtExpiration.Font = new System.Drawing.Font("Open Sans", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtExpiration.Location = new System.Drawing.Point(325, 550);
            this.dtExpiration.Name = "dtExpiration";
            this.dtExpiration.Size = new System.Drawing.Size(154, 22);
            this.dtExpiration.TabIndex = 12;
            // 
            // lblExpirationDate
            // 
            this.lblExpirationDate.AutoSize = true;
            this.lblExpirationDate.BackColor = System.Drawing.Color.Beige;
            this.lblExpirationDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblExpirationDate.Font = new System.Drawing.Font("Linux Biolinum G", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpirationDate.Location = new System.Drawing.Point(227, 555);
            this.lblExpirationDate.Name = "lblExpirationDate";
            this.lblExpirationDate.Size = new System.Drawing.Size(92, 17);
            this.lblExpirationDate.TabIndex = 13;
            this.lblExpirationDate.Text = "Expiration Date";
            // 
            // btnGoogle
            // 
            this.btnGoogle.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.btnGoogle.Font = new System.Drawing.Font("Linux Biolinum G", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGoogle.Location = new System.Drawing.Point(668, 555);
            this.btnGoogle.Name = "btnGoogle";
            this.btnGoogle.Size = new System.Drawing.Size(138, 23);
            this.btnGoogle.TabIndex = 14;
            this.btnGoogle.Text = "Search Recipes";
            this.btnGoogle.UseVisualStyleBackColor = false;
            this.btnGoogle.Click += new System.EventHandler(this.btnGoogle_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.BackColor = System.Drawing.Color.AntiqueWhite;
            this.btnRemove.Font = new System.Drawing.Font("Linux Biolinum G", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(668, 521);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(138, 23);
            this.btnRemove.TabIndex = 15;
            this.btnRemove.Text = "Remove Selected Items";
            this.btnRemove.UseVisualStyleBackColor = false;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // picError
            // 
            this.picError.Image = global::frmFirstPage.Properties.Resources.alert_triangleRed;
            this.picError.Location = new System.Drawing.Point(811, 231);
            this.picError.Name = "picError";
            this.picError.Size = new System.Drawing.Size(17, 18);
            this.picError.TabIndex = 16;
            this.picError.TabStop = false;
            this.picError.MouseHover += new System.EventHandler(this.hover_over);
            // 
            // btnQuit
            // 
            this.btnQuit.BackColor = System.Drawing.Color.MediumAquamarine;
            this.btnQuit.Font = new System.Drawing.Font("Open Sans", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuit.Location = new System.Drawing.Point(597, 474);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(171, 41);
            this.btnQuit.TabIndex = 17;
            this.btnQuit.Text = "Quit";
            this.btnQuit.UseVisualStyleBackColor = false;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // uctrlInventory1
            // 
            this.uctrlInventory1.Location = new System.Drawing.Point(200, 84);
            this.uctrlInventory1.Name = "uctrlInventory1";
            this.uctrlInventory1.Size = new System.Drawing.Size(708, 522);
            this.uctrlInventory1.TabIndex = 7;
            this.uctrlInventory1.Load += new System.EventHandler(this.uctrlInventory1_Load);
            // 
            // uctrlHome1
            // 
            this.uctrlHome1.BackColor = System.Drawing.SystemColors.Desktop;
            this.uctrlHome1.Location = new System.Drawing.Point(200, 77);
            this.uctrlHome1.Name = "uctrlHome1";
            this.uctrlHome1.Size = new System.Drawing.Size(708, 519);
            this.uctrlHome1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(908, 599);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.picError);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.btnGoogle);
            this.Controls.Add(this.lblExpirationDate);
            this.Controls.Add(this.dtExpiration);
            this.Controls.Add(this.lblFoodItem);
            this.Controls.Add(this.txtFoodItem);
            this.Controls.Add(this.btnAddFood);
            this.Controls.Add(this.stExpirationDate);
            this.Controls.Add(this.chkFoods);
            this.Controls.Add(this.uctrlInventory1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.uctrlHome1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picError)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnFoodList;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel selectionPanel;
        private uctrlHome uctrlHome1;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.CheckedListBox chkFoods;
        private System.Windows.Forms.ListBox stExpirationDate;
        private uctrlInventory uctrlInventory1;
        private System.Windows.Forms.Button btnAddFood;
        private System.Windows.Forms.TextBox txtFoodItem;
        private System.Windows.Forms.Label lblFoodItem;
        private System.Windows.Forms.DateTimePicker dtExpiration;
        private System.Windows.Forms.Label lblExpirationDate;
        private System.Windows.Forms.Button btnGoogle;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.PictureBox picError;
        private System.Windows.Forms.ToolTip ttErrorMsg;
        private System.Windows.Forms.Button btnQuit;
    }
}

